


#define vigraFUNC vigraCreateAdjacency
void vigraMexFunction(matlab::OutputArray outputs, matlab::InputArray inputs)
{    
	mxClassID inClass = mxGetClassID(inputs[0]);
	switch(inClass){
		case mxDOUBLE_CLASS:
			vigraFUNC<double>(outputs, inputs);	break;
		case mxSINGLE_CLASS:
			vigraFUNC<float>(outputs, inputs);		break;
        case mxINT8_CLASS:
			vigraFUNC<Int8>(outputs, inputs);		break;
		case mxINT16_CLASS:
			vigraFUNC<Int16>(outputs, inputs);		break;
		case mxINT32_CLASS:
			vigraFUNC<Int32>(outputs, inputs);		break;
		case mxINT64_CLASS:
			vigraFUNC<Int64>(outputs, inputs);		break;
        case mxUINT8_CLASS:
			vigraFUNC<UInt8>(outputs, inputs);		break;
		case mxUINT16_CLASS:
			vigraFUNC<UInt16>(outputs, inputs);	break;
		case mxUINT32_CLASS:
			vigraFUNC<UInt32>(outputs, inputs);	break;
		case mxUINT64_CLASS:
			vigraFUNC<UInt64>(outputs, inputs);	break;		
		default:
			mexErrMsgTxt("Input image must have type 'uint8'-16-32-64', 'int8-16-32-64' 'single' or 'double'.");
	}

}